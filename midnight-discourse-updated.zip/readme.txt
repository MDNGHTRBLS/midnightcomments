=== Midnight Discourse ===
Contributors: jaredcelemin
Tags: comments, ai, google-signin, voting, customization, gemini
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Advanced WordPress comment system with AI integration, Google Sign-In, voting, and complete customization by Jared Celemin.

== Description ==

Midnight Discourse is a complete replacement for WordPress's default comment system with modern features:

**Core Features:**
* Real-time guest commenting with name and email
* Voting system with up/down votes
* Complete admin settings panel that actually works
* Optimized for speed and SEO
* Mobile-responsive design

**AI-Powered Comments:**
* Context-aware AI comments using Google Gemini
* 25 unique AI usernames with smart rotation
* Auto-comments on new posts (12 minutes default)
* Auto-replies to user comments (20 minutes default)
* Custom Gemini API URL support

**Complete Customization:**
* Username color coding: Author/Admin/Editor, Guest Users, AI Comments
* Adjustable border radius for cards (20px) and buttons (10px)
* Professional design with your brand colors
* All settings accessible via WordPress admin

**Performance & Reliability:**
* Single-file architecture for maximum compatibility
* Scoped CSS prevents conflicts with themes
* Optimized database structure
* Admin menu that shows up in Settings

== Installation ==

1. Upload the plugin file to WordPress
2. Activate the plugin
3. Go to Settings → Midnight Discourse (it will appear!)
4. Enable the comment system
5. Configure colors and API keys as desired
6. Guest commenting works immediately

== Frequently Asked Questions ==

= Why wasn't the admin menu showing up before? =
Previous versions had initialization timing issues. This version fixes that with proper WordPress hook registration.

= Do I need API keys to use the plugin? =
No! Guest commenting works immediately. API keys are only needed for Google Sign-In and AI features.

= Will this affect my site's performance? =
No. The plugin is optimized for speed and only loads when comments are displayed.

= Can I customize the appearance? =
Yes! Full customization options including colors, border radius, and timing settings.

== Changelog ==

= 1.0.0 =
* Complete rewrite with single-file architecture
* Fixed admin menu registration issues
* Working guest commenting system
* Full AI integration with Gemini
* Complete customization options
* Author credit: Jared Celemin