<?php
/**
 * Plugin Name: Midnight Discourse
 * Plugin URI: https://example.com/midnight-discourse
 * Description: Advanced WordPress comment system with AI integration, Google Sign-In, and complete customization
 * Version: 1.0.0
 * Author: Jared Celemin
 * License: GPL v2 or later
 * Text Domain: midnight-discourse
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MIDNIGHT_DISCOURSE_VERSION', '1.0.0');
define('MIDNIGHT_DISCOURSE_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MIDNIGHT_DISCOURSE_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main plugin class
 */
class MidnightDiscourse {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Register hooks immediately
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_filter('the_content', array($this, 'add_comment_system'));
        
        // AJAX handlers
        add_action('wp_ajax_md_submit_comment', array($this, 'submit_comment'));
        add_action('wp_ajax_nopriv_md_submit_comment', array($this, 'submit_comment'));
        add_action('wp_ajax_md_vote_comment', array($this, 'vote_comment'));
        add_action('wp_ajax_nopriv_md_vote_comment', array($this, 'vote_comment'));
        add_action('wp_ajax_md_load_comments', array($this, 'load_comments'));
        add_action('wp_ajax_nopriv_md_load_comments', array($this, 'load_comments'));
        add_action('wp_ajax_md_trigger_ai_comment', array($this, 'trigger_ai_comment'));
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // AI scheduled tasks
        add_action('publish_post', array($this, 'schedule_auto_comment'), 10, 2);
        add_action('md_auto_comment_new_post', array($this, 'auto_comment_new_post'));
        add_action('md_auto_reply_comment', array($this, 'auto_reply_comment'));
    }
    
    public function activate() {
        // Create database tables
        $this->create_tables();
        
        // Set default options
        $defaults = array(
            'md_enabled' => 0,
            'md_google_client_id' => '',
            'md_gemini_api_key' => '',
            'md_gemini_api_url' => 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent',
            'md_color_author' => '#cfff00',
            'md_color_guest' => '#ffffff', 
            'md_color_ai' => '#e0e0e0',
            'md_border_radius_cards' => '20',
            'md_border_radius_buttons' => '10',
            'md_auto_comment_delay' => '12',
            'md_auto_reply_delay' => '20'
        );
        
        foreach ($defaults as $key => $value) {
            add_option($key, $value);
        }
        
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('md_auto_comment_new_post');
        wp_clear_scheduled_hook('md_auto_reply_comment');
        flush_rewrite_rules();
    }
    
    private function create_tables() {
        global $wpdb;
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Comments table
        $table_name = $wpdb->prefix . 'md_comments';
        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            post_id int(11) NOT NULL,
            parent_id int(11) DEFAULT 0,
            user_id int(11) DEFAULT NULL,
            guest_name varchar(100) DEFAULT NULL,
            guest_email varchar(100) DEFAULT NULL,
            comment_content text NOT NULL,
            comment_date datetime DEFAULT CURRENT_TIMESTAMP,
            is_approved tinyint(1) DEFAULT 1,
            is_ai_comment tinyint(1) DEFAULT 0,
            ai_username varchar(100) DEFAULT NULL,
            user_ip varchar(45) DEFAULT NULL,
            vote_score int(11) DEFAULT 0,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY parent_id (parent_id),
            KEY user_id (user_id)
        ) $charset_collate;";
        dbDelta($sql);
        
        // Votes table
        $table_name = $wpdb->prefix . 'md_comment_votes';
        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            comment_id int(11) NOT NULL,
            user_id int(11) DEFAULT NULL,
            user_ip varchar(45) DEFAULT NULL,
            vote_type enum('up','down') NOT NULL,
            vote_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_vote (comment_id, user_id, user_ip),
            KEY comment_id (comment_id)
        ) $charset_collate;";
        dbDelta($sql);
        
        // Guest users table
        $table_name = $wpdb->prefix . 'md_guest_users';
        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            guest_name varchar(100) NOT NULL,
            guest_email varchar(100) NOT NULL,
            user_ip varchar(45) NOT NULL,
            created_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_guest (guest_name, user_ip),
            KEY guest_email (guest_email)
        ) $charset_collate;";
        dbDelta($sql);
        
        // AI statistics table
        $table_name = $wpdb->prefix . 'md_ai_stats';
        $sql = "CREATE TABLE $table_name (
            id int(11) NOT NULL AUTO_INCREMENT,
            post_id int(11) NOT NULL,
            ai_username varchar(100) NOT NULL,
            comment_count int(11) DEFAULT 1,
            last_comment_date datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY unique_ai_post (post_id, ai_username)
        ) $charset_collate;";
        dbDelta($sql);
    }
    
    public function add_admin_menu() {
        add_options_page(
            'Midnight Discourse Settings',
            'Midnight Discourse',
            'manage_options',
            'midnight-discourse',
            array($this, 'admin_page')
        );
    }
    
    public function register_settings() {
        register_setting('midnight_discourse_settings', 'md_enabled');
        register_setting('midnight_discourse_settings', 'md_google_client_id');
        register_setting('midnight_discourse_settings', 'md_gemini_api_key');
        register_setting('midnight_discourse_settings', 'md_gemini_api_url');
        register_setting('midnight_discourse_settings', 'md_color_author');
        register_setting('midnight_discourse_settings', 'md_color_guest');
        register_setting('midnight_discourse_settings', 'md_color_ai');
        register_setting('midnight_discourse_settings', 'md_border_radius_cards');
        register_setting('midnight_discourse_settings', 'md_border_radius_buttons');
        register_setting('midnight_discourse_settings', 'md_auto_comment_delay');
        register_setting('midnight_discourse_settings', 'md_auto_reply_delay');
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Midnight Discourse Settings</h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('midnight_discourse_settings'); ?>
                <?php do_settings_sections('midnight_discourse_settings'); ?>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 20px;">
                    
                    <!-- Basic Settings -->
                    <div style="background: #fff; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
                        <h2>Basic Settings</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">Enable Comment System</th>
                                <td>
                                    <input type="checkbox" name="md_enabled" value="1" <?php checked(1, get_option('md_enabled', 0)); ?> />
                                    <p class="description">Enable the Midnight Discourse comment system</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Google Client ID</th>
                                <td>
                                    <input type="text" name="md_google_client_id" value="<?php echo esc_attr(get_option('md_google_client_id', '')); ?>" class="regular-text" />
                                    <p class="description">Enter your Google OAuth Client ID for Google Sign-In</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- AI Settings -->
                    <div style="background: #fff; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
                        <h2>AI Settings</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">Gemini API Key</th>
                                <td>
                                    <input type="password" name="md_gemini_api_key" value="<?php echo esc_attr(get_option('md_gemini_api_key', '')); ?>" class="regular-text" />
                                    <p class="description">Enter your Google Gemini API key for AI comments</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Gemini API URL</th>
                                <td>
                                    <input type="url" name="md_gemini_api_url" value="<?php echo esc_attr(get_option('md_gemini_api_url', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent')); ?>" class="regular-text" />
                                    <p class="description">Custom Gemini API endpoint URL</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Auto Comment Delay</th>
                                <td>
                                    <input type="number" name="md_auto_comment_delay" value="<?php echo esc_attr(get_option('md_auto_comment_delay', '12')); ?>" min="1" max="60" />
                                    <span>minutes after new post publication</span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Auto Reply Delay</th>
                                <td>
                                    <input type="number" name="md_auto_reply_delay" value="<?php echo esc_attr(get_option('md_auto_reply_delay', '20')); ?>" min="1" max="120" />
                                    <span>minutes after user comment</span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Manual AI Comment</th>
                                <td>
                                    <input type="url" id="md_custom_url" placeholder="https://yoursite.com/article-url" class="regular-text" />
                                    <button type="button" id="md_trigger_ai" class="button">Generate AI Comment</button>
                                    <p class="description">Enter any article URL to manually trigger a Gemini AI comment</p>
                                    <div id="md_ai_result" style="margin-top: 10px;"></div>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Design Settings -->
                    <div style="background: #fff; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
                        <h2>Design Settings</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">Card Border Radius</th>
                                <td>
                                    <input type="number" name="md_border_radius_cards" value="<?php echo esc_attr(get_option('md_border_radius_cards', '20')); ?>" min="0" max="50" />
                                    <span>px</span>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Button Border Radius</th>
                                <td>
                                    <input type="number" name="md_border_radius_buttons" value="<?php echo esc_attr(get_option('md_border_radius_buttons', '10')); ?>" min="0" max="25" />
                                    <span>px</span>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Username Colors -->
                    <div style="background: #fff; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
                        <h2>Username Colors</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">Author/Admin/Editor Color</th>
                                <td>
                                    <input type="color" name="md_color_author" value="<?php echo esc_attr(get_option('md_color_author', '#cfff00')); ?>" />
                                    <p class="description">Color for authors, administrators, and editors</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Guest User Color</th>
                                <td>
                                    <input type="color" name="md_color_guest" value="<?php echo esc_attr(get_option('md_color_guest', '#ffffff')); ?>" />
                                    <p class="description">Color for guest and signed-in users</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">AI Comment Color</th>
                                <td>
                                    <input type="color" name="md_color_ai" value="<?php echo esc_attr(get_option('md_color_ai', '#e0e0e0')); ?>" />
                                    <p class="description">Color for Gemini AI comments</p>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                </div>
                
                <?php submit_button(); ?>
            </form>
            
            <div style="margin-top: 30px; padding: 20px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 8px;">
                <h3>Plugin Status</h3>
                <p><strong>Version:</strong> 1.0.0</p>
                <p><strong>Author:</strong> Jared Celemin</p>
                <p><strong>Status:</strong> <?php echo get_option('md_enabled') ? '<span style="color: green;">Active</span>' : '<span style="color: red;">Disabled</span>'; ?></p>
                
                <h3>Setup Instructions</h3>
                <ol>
                    <li><strong>Enable the plugin</strong> using the checkbox above</li>
                    <li><strong>Google OAuth:</strong> Get Client ID from Google Developer Console</li>
                    <li><strong>Gemini AI:</strong> Get API key from Google AI Studio</li>
                    <li><strong>Customize:</strong> Adjust colors and design settings</li>
                    <li><strong>Guest commenting works immediately</strong> without any setup</li>
                </ol>
            </div>
        </div>
        
        <style>
        .form-table th {
            width: 200px;
            padding: 15px 10px 15px 0;
        }
        .form-table td {
            padding: 15px 10px;
        }
        .form-table input[type="color"] {
            width: 50px;
            height: 30px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-table input[type="number"] {
            width: 80px;
        }
        .form-table .regular-text {
            width: 100%;
        }
        #md_trigger_ai {
            margin-left: 10px;
            vertical-align: top;
        }
        #md_ai_result {
            padding: 10px;
            border-radius: 4px;
            display: none;
        }
        #md_ai_result.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        #md_ai_result.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#md_trigger_ai').click(function() {
                var url = $('#md_custom_url').val();
                var button = $(this);
                var result = $('#md_ai_result');
                
                if (!url) {
                    result.removeClass('success').addClass('error').text('Please enter a URL').show();
                    return;
                }
                
                button.prop('disabled', true).text('Generating...');
                result.hide();
                
                $.ajax({
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    type: 'POST',
                    data: {
                        action: 'md_trigger_ai_comment',
                        nonce: '<?php echo wp_create_nonce('md_admin_nonce'); ?>',
                        custom_url: url
                    },
                    success: function(response) {
                        button.prop('disabled', false).text('Generate AI Comment');
                        if (response.success) {
                            result.removeClass('error').addClass('success').text('AI comment generated successfully!').show();
                            $('#md_custom_url').val('');
                        } else {
                            result.removeClass('success').addClass('error').text(response.data || 'Failed to generate comment').show();
                        }
                    },
                    error: function() {
                        button.prop('disabled', false).text('Generate AI Comment');
                        result.removeClass('success').addClass('error').text('Network error. Please try again.').show();
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    public function enqueue_scripts() {
        // Only load on single posts/pages where comments would appear and if enabled
        if ((!is_single() && !is_page()) || !get_option('md_enabled', 0)) {
            return;
        }
        
        // Enqueue CSS
        wp_add_inline_style('wp-block-library', $this->get_inline_css());
        
        // Enqueue JavaScript
        wp_enqueue_script('jquery');
        wp_add_inline_script('jquery', $this->get_inline_js());
    }
    
    private function get_inline_css() {
        $author_color = get_option('md_color_author', '#cfff00');
        $guest_color = get_option('md_color_guest', '#ffffff');
        $ai_color = get_option('md_color_ai', '#e0e0e0');
        $card_radius = get_option('md_border_radius_cards', '20');
        $button_radius = get_option('md_border_radius_buttons', '10');
        
        return "
        #midnight-discourse-comments {
            margin: 30px 0;
            padding: 25px;
            background: #ffffff;
            border: 1px solid #e0e0e0;
            border-radius: {$card_radius}px;
            font-family: Roboto, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        #midnight-discourse-comments h3 {
            color: #333;
            margin-bottom: 25px;
            font-size: 24px;
            font-weight: 500;
        }
        #midnight-discourse-comments .md-comment-form {
            margin-bottom: 30px;
            padding: 20px;
            background: #fafafa;
            border: 1px solid #eee;
            border-radius: {$card_radius}px;
        }
        #midnight-discourse-comments .md-textarea {
            width: 100%;
            min-height: 100px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: {$button_radius}px;
            resize: vertical;
            font-family: inherit;
            font-size: 14px;
            background: #fff;
            box-sizing: border-box;
        }
        #midnight-discourse-comments .md-textarea:focus {
            outline: none;
            border-color: #000;
        }
        #midnight-discourse-comments .md-guest-inputs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin: 15px 0;
        }
        #midnight-discourse-comments .md-guest-input {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: {$button_radius}px;
            font-family: inherit;
            box-sizing: border-box;
        }
        #midnight-discourse-comments .md-button {
            background: #cfff00;
            color: #000;
            border: 1px solid transparent;
            padding: 12px 25px;
            border-radius: {$button_radius}px;
            cursor: pointer;
            font-weight: 500;
            margin-top: 15px;
            font-family: inherit;
            transition: background 0.2s;
        }
        #midnight-discourse-comments .md-button:hover {
            background: #b8e600;
        }
        #midnight-discourse-comments .md-comment {
            padding: 20px;
            border: 1px solid #eee;
            border-radius: {$card_radius}px;
            margin-bottom: 15px;
            background: #fafafa;
            transition: box-shadow 0.2s;
            position: relative;
        }
        #midnight-discourse-comments .md-comment:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        #midnight-discourse-comments .md-comment-meta {
            font-size: 13px;
            color: #666;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 10px;
            padding-right: 80px;
        }
        #midnight-discourse-comments .md-username-author {
            color: {$author_color} !important;
            font-weight: 600;
        }
        #midnight-discourse-comments .md-username-guest {
            color: {$guest_color} !important;
            font-weight: 500;
        }
        #midnight-discourse-comments .md-username-ai {
            color: {$ai_color} !important;
            font-weight: 500;
        }
        #midnight-discourse-comments .md-comment-content {
            line-height: 1.6;
            margin-bottom: 15px;
            color: #333;
        }
        #midnight-discourse-comments .md-comment-actions {
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        #midnight-discourse-comments .md-vote-btn {
            background: none;
            border: none;
            padding: 5px;
            cursor: pointer;
            font-size: 18px;
            font-weight: 900;
            line-height: 1;
            color: #999;
            transition: color 0.2s;
            min-width: 30px;
            text-align: center;
        }
        #midnight-discourse-comments .md-vote-btn:hover {
            color: #333;
        }
        #midnight-discourse-comments .md-vote-btn.voted {
            color: #cfff00;
        }
        #midnight-discourse-comments .vote-count {
            font-size: 12px;
            font-weight: 600;
            color: #666;
            margin-top: 2px;
        }
        #midnight-discourse-comments .md-message {
            padding: 12px 15px;
            border-radius: {$button_radius}px;
            margin-bottom: 15px;
        }
        #midnight-discourse-comments .md-message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        #midnight-discourse-comments .md-message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        @media (max-width: 768px) {
            #midnight-discourse-comments .md-guest-inputs {
                grid-template-columns: 1fr;
            }
            #midnight-discourse-comments .md-comment-actions {
                flex-wrap: wrap;
            }
        }
        ";
    }
    
    private function get_inline_js() {
        $nonce = wp_create_nonce('md_nonce');
        $ajax_url = admin_url('admin-ajax.php');
        $post_id = get_the_ID();
        
        return "
        jQuery(document).ready(function($) {
            var mdAjaxUrl = '{$ajax_url}';
            var mdNonce = '{$nonce}';
            var mdPostId = {$post_id};
            
            // Load initial comments
            loadComments();
            
            // Submit comment
            $('#md-comment-form').submit(function(e) {
                e.preventDefault();
                submitComment();
            });
            
            // Vote handlers
            $(document).on('click', '.md-vote-btn', function() {
                var commentId = $(this).data('comment-id');
                var voteType = $(this).data('vote');
                voteComment(commentId, voteType, $(this));
            });
            
            function submitComment() {
                var content = $('#md-comment-content').val().trim();
                var guestName = $('#md-guest-name').val();
                var guestEmail = $('#md-guest-email').val();
                
                if (!content) {
                    showMessage('Please enter a comment', 'error');
                    return;
                }
                
                if (!guestName) {
                    showMessage('Please enter your name', 'error');
                    return;
                }
                
                $.ajax({
                    url: mdAjaxUrl,
                    type: 'POST',
                    data: {
                        action: 'md_submit_comment',
                        nonce: mdNonce,
                        post_id: mdPostId,
                        parent_id: 0,
                        content: content,
                        guest_name: guestName,
                        guest_email: guestEmail
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#md-comment-content').val('');
                            $('#md-guest-name').val('');
                            $('#md-guest-email').val('');
                            showMessage('Comment posted successfully!', 'success');
                            loadComments();
                        } else {
                            showMessage(response.data || 'Failed to post comment', 'error');
                        }
                    },
                    error: function() {
                        showMessage('Network error. Please try again.', 'error');
                    }
                });
            }
            
            function voteComment(commentId, voteType, button) {
                $.ajax({
                    url: mdAjaxUrl,
                    type: 'POST',
                    data: {
                        action: 'md_vote_comment',
                        nonce: mdNonce,
                        comment_id: commentId,
                        vote_type: voteType
                    },
                    success: function(response) {
                        if (response.success) {
                            var comment = button.closest('.md-comment');
                            comment.find('.vote-count').text(response.data.vote_score);
                            
                            // Update button states
                            comment.find('.md-vote-btn').removeClass('voted');
                            if (response.data.vote_score > 0) {
                                comment.find('.md-vote-up').addClass('voted');
                            }
                        }
                    }
                });
            }
            
            function loadComments() {
                $.ajax({
                    url: mdAjaxUrl,
                    type: 'GET',
                    data: {
                        action: 'md_load_comments',
                        post_id: mdPostId
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#md-comments-list').html(response.data.comments_html);
                        }
                    }
                });
            }
            
            function showMessage(message, type) {
                var messageHtml = '<div class=\"md-message ' + type + '\">' + message + '</div>';
                $('#md-messages').html(messageHtml);
                setTimeout(function() {
                    $('#md-messages').empty();
                }, 5000);
            }
        });
        ";
    }
    
    public function add_comment_system($content) {
        // Only add to single posts/pages and if enabled
        if ((!is_single() && !is_page()) || !get_option('md_enabled', 0)) {
            return $content;
        }
        
        $comment_system = $this->render_comment_system();
        return $content . $comment_system;
    }
    
    private function render_comment_system() {
        ob_start();
        ?>
        <div id="midnight-discourse-comments">
            <h3>Comments</h3>
            
            <div id="md-messages"></div>
            
            <div class="md-comment-form">
                <form id="md-comment-form">
                    <textarea id="md-comment-content" class="md-textarea" placeholder="Share your thoughts..."></textarea>
                    
                    <div class="md-guest-inputs">
                        <input type="text" id="md-guest-name" class="md-guest-input" placeholder="Your name" required />
                        <input type="email" id="md-guest-email" class="md-guest-input" placeholder="Email (optional)" />
                    </div>
                    
                    <button type="submit" class="md-button">Post Comment</button>
                </form>
            </div>
            
            <div id="md-comments-list">
                <div class="md-comment">
                    <div class="md-comment-meta">
                        <strong class="md-username-guest">Demo User</strong>
                        <span>2 hours ago</span>
                    </div>
                    <div class="md-comment-content">
                        This is a demo comment. Guest commenting is now fully functional!
                    </div>
                    <div class="md-comment-actions">
                        <button class="md-vote-btn md-vote-up" data-comment-id="1" data-vote="up">
                            ▲
                        </button>
                        <div class="vote-count">0</div>
                        <button class="md-vote-btn md-vote-down" data-comment-id="1" data-vote="down">
                            ▼
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    // AJAX Handlers
    public function submit_comment() {
        check_ajax_referer('md_nonce', 'nonce');
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'md_comments';
        
        $post_id = intval($_POST['post_id']);
        $parent_id = intval($_POST['parent_id']);
        $content = sanitize_textarea_field($_POST['content']);
        $user_ip = $_SERVER['REMOTE_ADDR'];
        
        // Check if user is logged in
        $current_user = wp_get_current_user();
        $user_id = null;
        $guest_name = null;
        $guest_email = null;
        
        if ($current_user->ID > 0) {
            // Logged-in user
            $user_id = $current_user->ID;
        } else {
            // Guest user
            $guest_name = sanitize_text_field($_POST['guest_name']);
            $guest_email = sanitize_email($_POST['guest_email']);
            
            if (empty($guest_name)) {
                wp_send_json_error('Name is required for guest comments');
            }
        }
        
        if (empty($content)) {
            wp_send_json_error('Comment content is required');
        }
        
        $result = $wpdb->insert(
            $table_name,
            array(
                'post_id' => $post_id,
                'parent_id' => $parent_id,
                'user_id' => $user_id,
                'guest_name' => $guest_name,
                'guest_email' => $guest_email,
                'comment_content' => $content,
                'user_ip' => $user_ip,
                'is_approved' => 1,
                'comment_date' => current_time('mysql')
            ),
            array('%d', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%s')
        );
        
        if ($result) {
            $comment_id = $wpdb->insert_id;
            
            // Schedule AI reply if enabled
            if (get_option('md_gemini_api_key') && get_option('md_enabled')) {
                $delay = intval(get_option('md_auto_reply_delay', 20)) * 60;
                wp_schedule_single_event(time() + $delay, 'md_auto_reply_comment', array($comment_id));
            }
            
            wp_send_json_success(array(
                'comment_id' => $comment_id,
                'message' => 'Comment posted successfully'
            ));
        } else {
            wp_send_json_error('Failed to post comment');
        }
    }
    
    public function vote_comment() {
        check_ajax_referer('md_nonce', 'nonce');
        
        global $wpdb;
        $comment_id = intval($_POST['comment_id']);
        $vote_type = sanitize_text_field($_POST['vote_type']);
        $user_ip = $_SERVER['REMOTE_ADDR'];
        
        if (!in_array($vote_type, array('up', 'down'))) {
            wp_send_json_error('Invalid vote type');
        }
        
        $votes_table = $wpdb->prefix . 'md_comment_votes';
        $comments_table = $wpdb->prefix . 'md_comments';
        
        // Check if IP already voted
        $existing_vote = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $votes_table WHERE comment_id = %d AND user_ip = %s",
            $comment_id, $user_ip
        ));
        
        if ($existing_vote) {
            if ($existing_vote->vote_type === $vote_type) {
                // Remove vote if same type
                $wpdb->delete($votes_table, array('id' => $existing_vote->id));
            } else {
                // Update vote type
                $wpdb->update(
                    $votes_table,
                    array('vote_type' => $vote_type),
                    array('id' => $existing_vote->id)
                );
            }
        } else {
            // Insert new vote
            $wpdb->insert(
                $votes_table,
                array(
                    'comment_id' => $comment_id,
                    'user_ip' => $user_ip,
                    'vote_type' => $vote_type
                ),
                array('%d', '%s', '%s')
            );
        }
        
        // Update vote score
        $up_votes = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $votes_table WHERE comment_id = %d AND vote_type = 'up'",
            $comment_id
        ));
        
        $down_votes = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $votes_table WHERE comment_id = %d AND vote_type = 'down'",
            $comment_id
        ));
        
        $vote_score = $up_votes - $down_votes;
        
        $wpdb->update(
            $comments_table,
            array('vote_score' => $vote_score),
            array('id' => $comment_id),
            array('%d'),
            array('%d')
        );
        
        wp_send_json_success(array(
            'vote_score' => $vote_score,
            'up_votes' => $up_votes,
            'down_votes' => $down_votes
        ));
    }
    
    public function load_comments() {
        $post_id = intval($_GET['post_id']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'md_comments';
        
        $comments = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name 
             WHERE post_id = %d AND parent_id = 0 AND is_approved = 1
             ORDER BY comment_date DESC
             LIMIT 10",
            $post_id
        ));
        
        $comments_html = '';
        if ($comments) {
            foreach ($comments as $comment) {
                $comments_html .= $this->render_comment($comment);
            }
        } else {
            $comments_html = '<p style="text-align: center; color: #666; padding: 20px;">No comments yet. Be the first to comment!</p>';
        }
        
        wp_send_json_success(array(
            'comments_html' => $comments_html
        ));
    }
    
    private function render_comment($comment) {
        $author_color = get_option('md_color_author', '#cfff00');
        $guest_color = get_option('md_color_guest', '#ffffff');
        $ai_color = get_option('md_color_ai', '#e0e0e0');
        $card_radius = get_option('md_border_radius_cards', '20');
        
        $username_color = $guest_color;
        $username_class = 'md-username-guest';
        $username = $comment->guest_name ?: 'Anonymous';
        
        if ($comment->is_ai_comment) {
            $username_color = $ai_color;
            $username_class = 'md-username-ai';
            $username = $comment->ai_username;
        } elseif ($comment->user_id) {
            $user = get_userdata($comment->user_id);
            if ($user) {
                $user_roles = $user->roles;
                if (array_intersect($user_roles, array('administrator', 'editor', 'author'))) {
                    $username_color = $author_color;
                    $username_class = 'md-username-author';
                } else {
                    $username_class = 'md-username-guest';
                }
                $username = $user->display_name;
            }
        }
        
        // Fix timestamp calculation using WordPress timezone
        $comment_time = get_date_from_gmt($comment->comment_date);
        $time_ago = human_time_diff(strtotime($comment_time), current_time('timestamp')) . ' ago';
        
        ob_start();
        ?>
        <div class="md-comment" data-comment-id="<?php echo esc_attr($comment->id); ?>">
            <div class="md-comment-meta">
                <strong class="<?php echo esc_attr($username_class); ?>">
                    <?php echo esc_html($username); ?>
                </strong>
                <span><?php echo esc_html($time_ago); ?></span>
            </div>
            <div class="md-comment-content">
                <?php echo esc_html($comment->comment_content); ?>
            </div>
            <div class="md-comment-actions">
                <button class="md-vote-btn md-vote-up" data-comment-id="<?php echo esc_attr($comment->id); ?>" data-vote="up">
                    ▲
                </button>
                <div class="vote-count"><?php echo esc_html($comment->vote_score); ?></div>
                <button class="md-vote-btn md-vote-down" data-comment-id="<?php echo esc_attr($comment->id); ?>" data-vote="down">
                    ▼
                </button>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    // AI Comment Generation
    public function schedule_auto_comment($post_id, $post) {
        if (get_option('md_enabled', 0) && get_option('md_gemini_api_key')) {
            $delay = intval(get_option('md_auto_comment_delay', 12)) * 60;
            wp_schedule_single_event(time() + $delay, 'md_auto_comment_new_post', array($post_id));
        }
    }
    
    public function auto_comment_new_post($post_id) {
        if (!get_option('md_enabled', 0) || !get_option('md_gemini_api_key')) {
            return;
        }
        
        $this->generate_ai_comment($post_id);
    }
    
    public function auto_reply_comment($comment_id) {
        if (!get_option('md_enabled', 0) || !get_option('md_gemini_api_key')) {
            return;
        }
        
        global $wpdb;
        $comment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}md_comments WHERE id = %d",
            $comment_id
        ));
        
        if ($comment && !$comment->is_ai_comment) {
            $this->generate_ai_reply($comment);
        }
    }
    
    private function generate_ai_comment($post_id) {
        $post = get_post($post_id);
        if (!$post) return;
        
        $content = wp_strip_all_tags($post->post_content);
        $title = $post->post_title;
        
        $prompt = "You are commenting on a blog post titled '{$title}'. Here's an excerpt: " . 
                 substr($content, 0, 500) . "... " .
                 "Write a thoughtful, engaging comment (2-3 sentences) that shows you read and understood the content. " .
                 "Be conversational and add value to the discussion. Don't mention you're AI.";
        
        $ai_comment = $this->call_gemini_api($prompt);
        
        if ($ai_comment) {
            $this->save_ai_comment($post_id, 0, $ai_comment);
        }
    }
    
    private function generate_ai_reply($comment) {
        $post = get_post($comment->post_id);
        if (!$post) return;
        
        $post_title = $post->post_title;
        $comment_content = $comment->comment_content;
        $commenter_name = $comment->guest_name ?: 'the user';
        
        $prompt = "You're reading a blog post titled '{$post_title}'. " .
                 "{$commenter_name} commented: '{$comment_content}' " .
                 "Write a thoughtful reply (1-2 sentences) that engages with their comment. " .
                 "Be friendly and conversational. Don't mention you're AI.";
        
        $ai_reply = $this->call_gemini_api($prompt);
        
        if ($ai_reply) {
            $this->save_ai_comment($comment->post_id, $comment->id, $ai_reply);
        }
    }
    
    private function call_gemini_api($prompt) {
        $api_key = get_option('md_gemini_api_key');
        $api_url = get_option('md_gemini_api_url', 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent');
        
        if (!$api_key) return false;
        
        $data = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => $prompt)
                    )
                )
            ),
            'generationConfig' => array(
                'temperature' => 0.7,
                'topK' => 40,
                'topP' => 0.95,
                'maxOutputTokens' => 200
            )
        );
        
        $response = wp_remote_post($api_url . '?key=' . $api_key, array(
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($data),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $result = json_decode($body, true);
        
        if (isset($result['candidates'][0]['content']['parts'][0]['text'])) {
            return trim($result['candidates'][0]['content']['parts'][0]['text']);
        }
        
        return false;
    }
    
    private function save_ai_comment($post_id, $parent_id, $content) {
        global $wpdb;
        
        // AI usernames
        $ai_usernames = array(
            'DigitalNomad', 'TechSavvy', 'MusicMaven', 'CreativeGenius', 'InnovativeMin',
            'RetroVibes', 'SoundExplorer', 'BeatMaster', 'ElectroFan', 'MelodyMaker',
            'RhythmSeeker', 'SonicDreamer', 'AudioPhile', 'GrooveHunter', 'SynthWave',
            'BassDropper', 'TrebleBoost', 'FrequencyMod', 'WaveForm', 'DecibeLover',
            'HarmonicFlow', 'TempoShift', 'EchoEffect', 'ReverbMaster', 'DistortionKing'
        );
        
        $username = $ai_usernames[array_rand($ai_usernames)];
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'md_comments',
            array(
                'post_id' => $post_id,
                'parent_id' => $parent_id,
                'comment_content' => $content,
                'is_ai_comment' => 1,
                'ai_username' => $username,
                'user_ip' => '127.0.0.1',
                'is_approved' => 1,
                'comment_date' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s', '%d', '%s')
        );
        
        return $result;
    }
    
    // Custom AI Comment Trigger
    public function trigger_ai_comment() {
        check_ajax_referer('md_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $custom_url = sanitize_url($_POST['custom_url']);
        if (!$custom_url) {
            wp_send_json_error('Invalid URL provided');
        }
        
        // Extract post ID from URL
        $post_id = url_to_postid($custom_url);
        if (!$post_id) {
            wp_send_json_error('Could not find post for this URL');
        }
        
        // Check if post exists and comments are enabled
        $post = get_post($post_id);
        if (!$post) {
            wp_send_json_error('Post not found');
        }
        
        // Generate AI comment immediately
        $ai_comment_generated = $this->generate_ai_comment($post_id);
        
        if ($ai_comment_generated) {
            wp_send_json_success('AI comment generated successfully for: ' . $post->post_title);
        } else {
            wp_send_json_error('Failed to generate AI comment. Check your Gemini API key.');
        }
    }
}

// Initialize the plugin
MidnightDiscourse::get_instance();